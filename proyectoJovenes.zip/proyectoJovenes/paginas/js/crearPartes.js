
document.write("<header> <h1 onclick='window.open(index.html)'><a href='index.html'>Paxa's Store</a></h1><img src='img/icono.png' id='icono'><div id='buscador'><form><input type='text' name='buscarJuego' maxlength='100' id='barraBuscar' ><button type='button' class='btn btn-default' id='btnBuscar'><span class='glyphicon glyphicon-search'></span></button><button id='botonDesplegable' type='button' class='btn btn-default' ><span class='glyphicon glyphicon-th-list' ></span></button><div id='list'>	<a href='loginUsuario.html'>Login</a><a href='registroUsuario.html'>Registrarse</a><a href='6del11.html'>Comprar</a></div></form></div></header>");
  
	
	
	
	
		

