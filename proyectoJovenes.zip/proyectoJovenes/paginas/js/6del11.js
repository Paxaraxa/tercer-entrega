/* login */


/*data : /* json con todos los objetos */
  /*  "email": campoemail@val(),
    "firstname": "javier",
    "lastname": "valenzani",
    "password": "supersecreto1",
    "sex": "Male",
   "newsletter": true */
